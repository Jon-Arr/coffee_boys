bleeding watercolor � ThePerfectDayFonts 2012


"bleeding watercolor" is a font created and copyrighted by ThePerfectDayFonts

It is free for personal and non-profit use. If you need to use this for for commercial reasons please donate.

Please do not try to claim as your own. You may redistribute, but only including this non-edited Read Me file as well.

Thanks for downloading, and if you have any comments or concerns please contact me at my dafont.com profile.



